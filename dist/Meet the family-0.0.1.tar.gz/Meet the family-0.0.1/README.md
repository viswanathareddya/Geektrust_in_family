Solving th problem of family tree provided by Geektrust.

creating solution for adding a child to mother who is existing in the family.

Getting the relatives names of corresponding relations for a given member of family